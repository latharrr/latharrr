<picture>
  <source media="(prefers-color-scheme: dark) and (max-width: 640px)" srcset="art/hero-mobile-dark.svg">
  <source media="(prefers-color-scheme: dark)" srcset="art/hero-dark.svg">
  <source media="(max-width: 640px)" srcset="art/hero-mobile-light.svg">
  <img width="100%" alt="Software that shows its work. Deepanshu Lathar, full-stack and AI engineer in Delhi, India." src="art/hero-light.svg">
</picture>

[Website](https://deepanshulathar.com) · [Writing](https://deepanshulathar.com/sidequests) · [LinkedIn](https://www.linkedin.com/in/deepanshulathar/) · [Résumé](https://deepanshulathar.com/Deepanshu-Lathar-Resume.pdf) · [Email](mailto:deepanshulathar@gmail.com)

<picture>
  <source media="(prefers-color-scheme: dark) and (max-width: 640px)" srcset="art/s1-mobile-dark.svg">
  <source media="(prefers-color-scheme: dark)" srcset="art/s1-dark.svg">
  <source media="(max-width: 640px)" srcset="art/s1-mobile-light.svg">
  <img width="100%" alt="A bank statement is scanned, one row is flagged and a FAIL stamp lands." src="art/s1-light.svg">
</picture>

**[ProofMart](https://proofmart.shop)** · live beta · [repo](https://github.com/latharrr/Proofmart.shop)<br>
Checks PDF bank statements by re-adding the rows. Verdicts come from fixed rules, and each finding is pinned to a place on the page with the sum that proves it. Next.js, TypeScript, Supabase.<br>
<sub>Illustration of the idea, not live output.</sub>

<picture>
  <source media="(prefers-color-scheme: dark) and (max-width: 640px)" srcset="art/s2-mobile-dark.svg">
  <source media="(prefers-color-scheme: dark)" srcset="art/s2-dark.svg">
  <source media="(max-width: 640px)" srcset="art/s2-mobile-light.svg">
  <img width="100%" alt="Two phones each get a check mark, then a padlock opens." src="art/s2-light.svg">
</picture>

**[LpuTV](https://lputv.vercel.app)** · live · [repo](https://github.com/latharrr/lpuconnect)<br>
Anonymous ten-minute text chat for LPU students. Extending a chat or becoming friends needs both people to agree, and the server checks it. A test asserts message text is never written to the database. Express, Socket.IO, WebRTC, SQLite.<br>
<sub>Illustration of the idea, not live output.</sub>

<picture>
  <source media="(prefers-color-scheme: dark) and (max-width: 640px)" srcset="art/s3-mobile-dark.svg">
  <source media="(prefers-color-scheme: dark)" srcset="art/s3-dark.svg">
  <source media="(max-width: 640px)" srcset="art/s3-mobile-light.svg">
  <img width="100%" alt="A token hits a timeout on the primary track and is rerouted along a backup track." src="art/s3-light.svg">
</picture>

**[Gapl](https://gapl.vercel.app)** · pre-launch demo · [repo](https://github.com/latharrr/gapl)<br>
Simulates a recruiter's screen of a resume against a target role, then builds a roadmap for the gaps. User-facing AI tasks run through one gateway that falls back to a backup model and tracks cost per call. Next.js, Firebase, Anthropic.<br>
<sub>Illustration of the idea, not live output.</sub>

<picture>
  <source media="(prefers-color-scheme: dark) and (max-width: 640px)" srcset="art/s4-mobile-dark.svg">
  <source media="(prefers-color-scheme: dark)" srcset="art/s4-dark.svg">
  <source media="(max-width: 640px)" srcset="art/s4-mobile-light.svg">
  <img width="100%" alt="A gate rejects a note that says 10x growth and lets a note with a check mark through." src="art/s4-light.svg">
</picture>

**[LinkedIn drafting bot](https://github.com/latharrr/linkedin-bot)** · public repo<br>
A Telegram-controlled assistant for drafting and scheduling posts. A deterministic grounding gate checks drafts for claims about me that nothing backs up and holds back the ones that fail. Python.<br>
<sub>Illustration of the idea, not live output.</sub>

Also: [College-CLI](https://github.com/latharrr/college-cli) (pre-release, run from source), [Dandiya Nights](https://github.com/latharrr/dandiya-night-pp) (ran live, Navratri 2026), [Deepanshu Labs](https://deepanshulathar.com/labs/whatsapp-receptionist) (live WhatsApp receptionist).

<details>
<summary><b>How each one decides</b></summary>

- **ProofMart:** rules run over the page's own numbers and the verdict is picked in a fixed order: `INCONCLUSIVE`, `FAIL`, `REVIEW`, `CLEAR`. A rule without enough columns reports "insufficient data". Dossier PDFs carry an Ed25519 signature, and the verification endpoint is public and needs no account.
- **LpuTV:** the server holds each chat's consent state, so the two-sided steps (extending a chat, becoming friends) are checked there, with tests behind it.
- **Gapl:** one gateway runs the user-facing AI tasks, tries a backup model when the primary fails and records cost per call.
- **LinkedIn bot:** a deterministic gate checks drafts for lines lifted from my profile, repeated stories and numbers about me that nothing backs. A draft with a `[verify]` tag cannot be scheduled.

</details>

## Recent commits

Updated daily from the GitHub API, latest commit per project.

- `26 Oct` **linkedin-bot**: [Telegram bot review fixes: filler re-prompt, question memory, pending-interacti…](https://github.com/latharrr/linkedin-bot/commit/1ea97d6e579135af5dbd3ebb8597790f75a8001e)
- `25 Oct` **ProofMart**: [JWKS cache: reject malformed key sets \+ regression tests for auth-sensitive pat…](https://github.com/latharrr/Proofmart.shop/commit/74c7397f1df50472f8d4c60de311c632c710a57c)
- `25 Oct` **College-CLI**: [docs: state that college-cli is not on npm yet; run from source](https://github.com/latharrr/college-cli/commit/278468e01242182cde1d453285a96fda223c4135)
- `25 Oct` **LpuTV**: [fix\(deps\): bump body-parser 2.3.0 to 2.4.0 \(GHSA-27r3-jxmh-p828\); lockfile only](https://github.com/latharrr/lpuconnect/commit/3aed5ce242db160c3ce875c40738c05bd63d712e)
- `25 Oct` **Gapl**: [Merge pull request \#5 from latharrr/docs/project-status](https://github.com/latharrr/gapl/commit/90457ece37e9899c78dcdd8c63358349a0fb864b)

<sub>Open to Summer 2027 internships</sub>
